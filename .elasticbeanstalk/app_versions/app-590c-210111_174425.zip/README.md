# solaria

## Pre Push

on mesada directory:

    isort -y
    black .
    flake8 