from django.apps import AppConfig


class TransferConfig(AppConfig):
    name = "transfer"
